# Extreme Thermals

Disable Agressive Thermal Throttling


# Instructions
1. Install via Magisk Manager
2. Reboot